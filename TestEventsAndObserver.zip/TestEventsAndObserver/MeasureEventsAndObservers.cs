// <copyright company="ROSEN Swiss AG">
//  Copyright (c) ROSEN Swiss AG
//  This computer program includes confidential, proprietary
//  information and is a trade secret of ROSEN. All use,
//  disclosure, or reproduction is prohibited unless authorized in
//  writing by an officer of ROSEN. All Rights Reserved.
// </copyright>

namespace TestEventsAndObserver
{
    using System;
    using System.Diagnostics;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    #region MeasureEventArgsAndObserver_Test
    public class ContentClass
    {
        #region Fields

        #endregion

        #region Properties

        public byte[] Bytes { get; } = new byte[1024];

        public double Number { get; } = Math.E;

        #endregion
    }

    public class SenderReceiver : IObservable<Object>, IObserver<Object>
    {
        #region Fields

        Stopwatch sw = new Stopwatch();

        #endregion

        #region Properties

        public long TicksPassed { get; private set; }

        #endregion

        #region Methods

        public void OnCompleted()
        {
            throw new NotImplementedException();
        }

        public void OnError(Exception error)
        {
            throw new NotImplementedException();
        }

        public void OnNext(object value)
        {
            this.TicksPassed += this.sw.ElapsedTicks;
            this.sw.Stop();
        }

        public void Send(Object o)
        {
            this.sw.Restart();
            this.OnNext(o);
        }

        public IDisposable Subscribe(IObserver<object> observer)
        {
            throw new NotImplementedException();
        }

        #endregion
    }

    public class TestEventHandler
    {
        #region Fields

        EventHandler<Object> Relay = null;

        Stopwatch sw = new Stopwatch();

        #endregion

        #region Properties

        public long TicksPassed { get; private set; }

        #endregion

        #region Constructors

        public TestEventHandler()
        {
            this.Relay += OnRelay;
        }

        #endregion

        #region Methods

        private void OnRelay(object sender, object e)
        {
            this.TicksPassed += this.sw.ElapsedTicks;
            this.sw.Stop();
        }

        public void Send(Object o)
        {
            this.sw.Restart();
            this.Relay.Invoke(o, EventArgs.Empty);
        }

        public void SendWithArgs(Object o)
        {
            this.sw.Restart();
            this.Relay.Invoke(this, new TestEventHandlerEventArgs(o));
        }

        #endregion

        public class TestEventHandlerEventArgs : EventArgs
        {
            #region Fields

            #endregion

            #region Properties

            public Object Content { get; }

            #endregion

            #region Constructors

            public TestEventHandlerEventArgs(Object o)
            {
                this.Content = o;
            }

            #endregion
        }
    }

    #endregion

    [TestClass]
    public class MeasureEventsAndObservers
    {
        #region Methods

        [TestMethod]
        public void MeasureEventArgsAndObserver()
        {
            var teh = new TestEventHandler();
            var obb = new SenderReceiver();

            for (int i = 1; i < 10; i++)
            {
                long eventArgs = 0, observer = 0, withoutEventArgs = 0;
                int maxItterations = i * 100000;
                var content = new object();

                for (int j = 0; j < maxItterations; j++)
                {
                    teh.Send(content);
                    withoutEventArgs += teh.TicksPassed;

                    obb.Send(content);
                    observer += obb.TicksPassed;

                    teh.SendWithArgs(content);
                    eventArgs += teh.TicksPassed;
                }

                PrintMeasureEventArgsAndObserver(withoutEventArgs, observer, eventArgs, maxItterations);
            }
        }

        [TestMethod]
        public void MeasureEventArgsAndObserverWithData()
        {
            var teh = new TestEventHandler();
            var obb = new SenderReceiver();

            for (int i = 1; i < 10; i++)
            {
                long eventArgs = 0, observer = 0, withoutEventArgs = 0;
                int maxItterations = i * 100000;

                var content = new ContentClass();

                for (int j = 0; j < maxItterations; j++)
                {
                    teh.Send(content);
                    withoutEventArgs += teh.TicksPassed;

                    obb.Send(content);
                    observer += obb.TicksPassed;

                    teh.SendWithArgs(content);
                    eventArgs += teh.TicksPassed;
                }

                PrintMeasureEventArgsAndObserver(withoutEventArgs, observer, eventArgs, maxItterations);
            }
        }

        static void PrintMeasureEventArgsAndObserver(long time, long time2, long time3, int itterations)
        {
            long count = itterations * 1000;
            Trace.WriteLine($"Event withoutEventArgs {(long)(time / count)} - Event {(long)(time3 / count)} - Observer {(long)(time2 / count)} ");
        }

        #endregion
    }
}