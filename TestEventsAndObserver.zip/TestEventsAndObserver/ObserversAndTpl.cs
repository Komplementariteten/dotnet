﻿// <copyright company="ROSEN Swiss AG">
//  Copyright (c) ROSEN Swiss AG
//  This computer program includes confidential, proprietary
//  information and is a trade secret of ROSEN. All use,
//  disclosure, or reproduction is prohibited unless authorized in
//  writing by an officer of ROSEN. All Rights Reserved.
// </copyright>

namespace TestEventsAndObserver
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Security.Cryptography;
    using System.Threading;
    using System.Threading.Tasks;
    using System.Threading.Tasks.Dataflow;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    #region HelperClasses

    public class ObservableOutPut
    {
        #region Properties

        public byte[] ByteContent { get; private set; }

        public int Id { get; private set; }

        #endregion

        #region Constructors

        public ObservableOutPut(byte[] dataBytes, int id)
        {
            this.Id = id;
            for (int i = 0; i < 200; i++)
            {
                using (SHA256 mysha256 = SHA256.Create())
                {
                    this.ByteContent = mysha256.ComputeHash(dataBytes);
                }
            }
        }

        #endregion
    }

    public class ObserverContent : ContentClass
    {
        #region Properties

        public int Id { get; }

        #endregion

        #region Constructors

        public ObserverContent(int number)
        {
            this.Id = number;
        }

        #endregion
    }

    public class DataGennerator : IObservable<ObserverContent>
    {
        #region Fields

        private readonly List<IObserver<ObserverContent>> contentClassObservers = new List<IObserver<ObserverContent>>(2);

        #endregion

        #region Methods

        private void CompletSending()
        {
            foreach (var observer in this.contentClassObservers)
            {
                observer.OnCompleted();
            }
        }

        private void NotifyObservers(ObserverContent content)
        {
            foreach (var observer in this.contentClassObservers)
            {
                observer.OnNext(content);
            }
        }

        public void Send(uint number, CancellationToken token, TimeSpan delayBetweenSends)
        {
            for (int i = 0; i < number; i++)
            {
                NotifyObservers(new ObserverContent(i));
                Task.Delay(delayBetweenSends).Wait(token);
            }

            this.CompletSending();
        }

        public IDisposable Subscribe(IObserver<ObserverContent> observer)
        {
            if (!this.contentClassObservers.Contains(observer))
            {
                this.contentClassObservers.Add(observer);
            }

            return new Unsubscriber(this.contentClassObservers, observer);
        }

        #endregion

        private class Unsubscriber : IDisposable
        {
            #region Fields

            private IObserver<ObserverContent> _observer;

            private IList<IObserver<ObserverContent>> _observers;

            #endregion

            #region Constructors

            public Unsubscriber(IList<IObserver<ObserverContent>> observers, IObserver<ObserverContent> observer)
            {
                _observers = observers;
                _observer = observer;
            }

            #endregion

            #region Methods

            public void Dispose()
            {
                if (_observer != null && _observers.Contains(_observer))
                    _observers.Remove(_observer);
            }

            #endregion
        }
    }

    #endregion

    public static class SenderFactory<TInput, TContent>
    {
        #region Methods

        public static IObservable<TContent> CreateDataFlowFromObservable(IObservable<TInput> observable, Func<TInput, TContent> action, CancellationToken token)
        {
            var relayBlock = new BufferBlock<TInput>();
            var transform = new TransformBlock<TInput, TContent>(
                action,
                new ExecutionDataflowBlockOptions() { MaxDegreeOfParallelism = 10, EnsureOrdered = false, BoundedCapacity = 40, CancellationToken = token });

            relayBlock.LinkTo(transform);
            var relayObserver = relayBlock.AsObserver();

            observable.Subscribe(relayObserver);

            return transform.AsObservable();
        }

        #endregion
    }

    [TestClass]
    public class ObserversAndTpl
    {
        #region Methods

        [TestMethod]
        public void SomeObservableBasics()
        {
            var contentObservable = new DataGennerator();
            
            CancellationTokenSource tokenSource = new CancellationTokenSource();

            var parralelObservable = SenderFactory<ObserverContent, ObservableOutPut>.CreateDataFlowFromObservable(
                contentObservable,
                input => { return new ObservableOutPut(input.Bytes, input.Id); },
                tokenSource.Token);
            
            parralelObservable.Subscribe((c) => Trace.WriteLine($"Source ID: {c.Id}, Thread: {Thread.CurrentThread.ManagedThreadId}"));
            
            contentObservable.Send(100, tokenSource.Token, TimeSpan.FromMilliseconds(10));
        }

        #endregion
    }
}