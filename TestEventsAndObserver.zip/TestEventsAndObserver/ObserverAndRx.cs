﻿// <copyright company="ROSEN Swiss AG">
//  Copyright (c) ROSEN Swiss AG
//  This computer program includes confidential, proprietary
//  information and is a trade secret of ROSEN. All use,
//  disclosure, or reproduction is prohibited unless authorized in
//  writing by an officer of ROSEN. All Rights Reserved.
// </copyright>

namespace TestEventsAndObserver
{
    using System;
    using System.Diagnostics;
    using System.Linq;
    using System.Reactive.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ObserverAndRx
    {
        [TestMethod]
        public void TestBasicFiltering()
        {
            var range = Observable.Range(10, 20);

            var eventRange = range.Where(value => value % 2 == 0);

            eventRange.Subscribe((i) => Trace.WriteLine($"Even:{i}"), () => Trace.WriteLine("Completed"));

            var tensRange = range.Where(value => value % 10 == 0);

            tensRange.Subscribe((i) => Trace.WriteLine($"Tens:{i}"), () => Trace.WriteLine("Completed"));
        }

        [TestMethod]
        public void TestBasicTransformation()
        {
            var range = Observable.Range(10, 20);

            var byteRange = range.Select(i => BitConverter.GetBytes(i));

            byteRange.Subscribe(b => Trace.WriteLine($"{b.GetType()} {BitConverter.ToString(b)}"));
        }
    }
}